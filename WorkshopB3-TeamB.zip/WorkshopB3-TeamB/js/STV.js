$(document).ready(function () {
    $("#banner").show();

  

})

